package com.example.carrentalapp;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.media.MediaCas;
import android.os.Bundle;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;

import java.io.File;
import java.io.InputStream;

public class CarDetailsActivity extends AppCompatActivity {

    private ImageView imgCarDetail;
    private TextView tvCarName, tvCarBrand, tvCarType, tvCarDesc, tvCarPrice, tvCarAvailability;
    private MaterialButton btnRentNow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_details);

        imgCarDetail = findViewById(R.id.imgCarDetail);
        tvCarName = findViewById(R.id.tvCarNameDetail);
        tvCarBrand = findViewById(R.id.tvCarBrandDetail);
        tvCarType = findViewById(R.id.tvCarTypeDetail);
        tvCarDesc = findViewById(R.id.tvCarDescDetail);
        tvCarPrice = findViewById(R.id.tvCarPriceDetail);
        tvCarAvailability = findViewById(R.id.tvCarAvailabilityDetail);
        btnRentNow = findViewById(R.id.btnRentNow);

        // Retrieve car data from intent
        int carId = getIntent().getIntExtra("CAR_ID", -1);
        String name = getIntent().getStringExtra("CAR_NAME");
        String brand = getIntent().getStringExtra("CAR_BRAND");
        String type = getIntent().getStringExtra("CAR_TYPE");
        String description = getIntent().getStringExtra("CAR_DESC");
        double price = getIntent().getDoubleExtra("CAR_PRICE", 0.0);
        int available = getIntent().getIntExtra("CAR_AVAILABLE", 1);
        String imagePath = getIntent().getStringExtra("CAR_IMAGE");

        // Display data
        tvCarName.setText(name);
        tvCarBrand.setText(brand);
        tvCarType.setText(type);
        tvCarDesc.setText(description);
        tvCarPrice.setText("RM " + price + " /day");
        tvCarAvailability.setText(available == 1 ? "Available" : "Rented Out");
        tvCarAvailability.setTextColor(getColor(available == 1 ? R.color.green : R.color.red));

        // Load image from assets (temporary)
        if (imagePath != null && !imagePath.isEmpty()) {
            File imgFile = new File(imagePath);
            if (imgFile.exists()) {
                Bitmap bitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
                imgCarDetail.setImageBitmap(bitmap);
            } else {
                imgCarDetail.setImageResource(R.drawable.browsecar_image); // fallback
            }
        } else {
            imgCarDetail.setImageResource(R.drawable.browsecar_image); // fallback
        }


        btnRentNow.setOnClickListener(v -> {
            if (available == 0) {
                Toast.makeText(this, "This car is currently rented out.", Toast.LENGTH_SHORT).show();
                return;
            }

            showDateSelectionDialog(carId, price);
        });
    }

    private void showDateSelectionDialog(int carID, double pricePerDay) {
        // Use a simple AlertDialog with two DatePickers
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("Select Rental Dates");

        // Inflate a custom layout for date selection
        android.view.View view = getLayoutInflater().inflate(R.layout.dialog_select_dates, null);
        builder.setView(view);

        DatePicker startDatePicker = view.findViewById(R.id.startDatePicker);
        DatePicker endDatePicker = view.findViewById(R.id.endDatePicker);

        builder.setPositiveButton("Confirm", (dialog, which) -> {
            // Extract selected dates
            String startDate = startDatePicker.getYear() + "-" + (startDatePicker.getMonth() + 1) + "-" + startDatePicker.getDayOfMonth();
            String endDate = endDatePicker.getYear() + "-" + (endDatePicker.getMonth() + 1) + "-" + endDatePicker.getDayOfMonth();

            // Calculate total price
            long diff = getDateDiff(startDate, endDate);
            double totalPrice = diff * pricePerDay;

            // Get logged in user (assuming session or static variable)
            int userId = SessionManager.getInstance(this).getUserId();

            // Save booking
            DataBaseHelper dbHelper = new DataBaseHelper(this);
            boolean success = dbHelper.insertBooking(userId, carID, startDate, endDate, totalPrice);

            if (success) {
                Toast.makeText(this, "Booking confirmed! RM " + totalPrice, Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Failed to book the car.", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private long getDateDiff(String start, String end) {
        try {
            java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd");
            java.util.Date date1 = sdf.parse(start);
            java.util.Date date2 = sdf.parse(end);
            long diff = date2.getTime() - date1.getTime();
            return java.util.concurrent.TimeUnit.DAYS.convert(diff, java.util.concurrent.TimeUnit.MILLISECONDS) + 1;
        } catch (Exception e) {
            return 1;
        }
    }
}
