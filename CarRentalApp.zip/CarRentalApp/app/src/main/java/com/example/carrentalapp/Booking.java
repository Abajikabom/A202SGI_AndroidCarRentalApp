package com.example.carrentalapp;

public class Booking {
    private int id;
    private int carId;
    private String startDate;
    private String endDate;
    private double totalPrice;
    private String status;
    private String carName; // optional for display

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getCarId() { return carId; }
    public void setCarId(int carId) { this.carId = carId; }

    public String getStartDate() { return startDate; }
    public void setStartDate(String startDate) { this.startDate = startDate; }

    public String getEndDate() { return endDate; }
    public void setEndDate(String endDate) { this.endDate = endDate; }

    public double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(double totalPrice) { this.totalPrice = totalPrice; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getCarName() { return carName; }
    public void setCarName(String carName) { this.carName = carName; }
}
