package com.example.carrentalapp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.carrentalapp.R;
import com.example.carrentalapp.CarDB;

import java.io.File;
import java.io.InputStream;
import java.util.List;

public class CarAdapter extends RecyclerView.Adapter<CarAdapter.CarViewHolder> {

    private Context context;
    private List<CarDB> carList;
    private OnCarClickListener listener;
    public interface OnCarClickListener {
        void onCarClick(CarDB car);
    }

    public CarAdapter(Context context, List<CarDB> carList, OnCarClickListener listener) {
        this.context = context;
        this.carList = carList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public CarViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_car, parent, false);
        return new CarViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CarViewHolder holder, int position) {
        CarDB car = carList.get(position);
        holder.tvCarName.setText(car.getCarName());
        holder.tvCarBrand.setText(car.getBrand());
        holder.tvCarDesc.setText(car.getDescription());
        holder.tvCarPrice.setText("RM " + car.getPricePerDay() + "/day");

        if (car.getAvailable() == 1) {
            holder.tvAvailability.setText("Available");
            holder.tvAvailability.setTextColor(context.getColor(R.color.green));
        } else {
            holder.tvAvailability.setText("Rented Out");
            holder.tvAvailability.setTextColor(context.getColor(R.color.red));
        }

        String imagePath = car.getImage();

        if (imagePath == null || imagePath.isEmpty()) {
            holder.imgCar.setImageResource(R.drawable.browsecar_image);
        } else {
            File imgFile = new File(car.getImage());

            if (imgFile.exists()) {
                Bitmap bitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
                holder.imgCar.setImageBitmap(bitmap);
            } else {
                try {
                    InputStream ims = context.getAssets().open("car_images/" + imagePath);
                    Drawable d = Drawable.createFromStream(ims, null);
                    holder.imgCar.setImageDrawable(d);
                    ims.close();
                    Toast.makeText(context, "Loaded from assets: " + imagePath, Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    holder.imgCar.setImageResource(R.drawable.browsecar_image);
                }
            }
        }

        holder.itemView.setOnClickListener(v -> {
            listener.onCarClick(car);
            Toast.makeText(context, "Selected " + car.getCarName(), Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public int getItemCount() {
        return carList.size();
    }

    static class CarViewHolder extends RecyclerView.ViewHolder {
        ImageView imgCar;
        TextView tvCarName, tvCarBrand, tvCarDesc, tvCarPrice, tvAvailability;

        CarViewHolder(View itemView) {
            super(itemView);
            imgCar = itemView.findViewById(R.id.imgCar);
            tvCarName = itemView.findViewById(R.id.tvCarName);
            tvCarBrand = itemView.findViewById(R.id.tvCarBrand);
            tvCarDesc = itemView.findViewById(R.id.tvCarDesc);
            tvCarPrice = itemView.findViewById(R.id.tvCarPrice);
            tvAvailability = itemView.findViewById(R.id.tvCarAvailability);
        }
    }


}
