package com.example.carrentalapp;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class RentYourCarActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;

    private EditText etCarName, etBrand, etType, etPrice, etDescription;
    private ImageView imgPreview;
    private Button btnUploadImage, btnSubmit;
    private Uri selectedImageUri;

    private DataBaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rent_your_car);

        dbHelper = new DataBaseHelper(this);

        etCarName = findViewById(R.id.etCarName);
        etBrand = findViewById(R.id.etBrand);
        etType = findViewById(R.id.etType);
        etPrice = findViewById(R.id.etPrice);
        etDescription = findViewById(R.id.etDescription);
        imgPreview = findViewById(R.id.imgPreview);
        btnUploadImage = findViewById(R.id.btnUploadImage);
        btnSubmit = findViewById(R.id.btnSubmit);

        btnUploadImage.setOnClickListener(v -> openGallery());
        btnSubmit.setOnClickListener(v -> uploadCar());
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null) {
            selectedImageUri = data.getData();
            imgPreview.setImageURI(selectedImageUri);
        }
    }

    private void uploadCar() {
        String name = etCarName.getText().toString().trim();
        String brand = etBrand.getText().toString().trim();
        String type = etType.getText().toString().trim();
        String priceStr = etPrice.getText().toString().trim();
        String description = etDescription.getText().toString().trim();

        if (name.isEmpty() || brand.isEmpty() || type.isEmpty() || priceStr.isEmpty() || selectedImageUri == null) {
            Toast.makeText(this, "Please fill all fields and select an image", Toast.LENGTH_SHORT).show();
            return;
        }

        double price = Double.parseDouble(priceStr);
        int userId = SessionManager.getInstance(this).getUserId();

        // Save image to internal storage
        String imagePath = saveImageToInternalStorage(selectedImageUri, name);

        boolean success = dbHelper.insertCar(userId, name, brand, type, price, 1, imagePath, description);

        if (success) {
            Toast.makeText(this, "Car uploaded successfully!", Toast.LENGTH_LONG).show();
            finish(); // return to previous page
        } else {
            Toast.makeText(this, "Failed to upload car.", Toast.LENGTH_SHORT).show();
        }
    }

    private String saveImageToInternalStorage(Uri imageUri, String carName) {
        try {
            Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);
            File directory = new File(getFilesDir(), "car_images");
            if (!directory.exists()) directory.mkdirs();

            String fileName = carName.replaceAll("\\s+", "_") + ".jpg";
            File file = new File(directory, fileName);

            FileOutputStream fos = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos);
            fos.close();

            return file.getAbsolutePath();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}
