package com.example.carrentalapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class RegisterActivity extends AppCompatActivity {
    EditText rgtrName, rgtrEmail, rgtrPassword;
    Button btnRegisterSubmit;
    DataBaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        db = new DataBaseHelper(this);
        rgtrName = findViewById(R.id.rgtrName);
        rgtrEmail = findViewById(R.id.rgtrEmail);
        rgtrPassword = findViewById(R.id.rgtrPassword);
        btnRegisterSubmit = findViewById(R.id.btnRegisterSubmit);

        btnRegisterSubmit.setOnClickListener(v -> {
            String name = rgtrName.getText().toString();
            String email = rgtrEmail.getText().toString();
            String password = rgtrPassword.getText().toString();

            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else if (db.insertUser(name, email, password)) {
                Toast.makeText(this, "Register Successful!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, LoginActivity.class));
                finish();
            } else {
                Toast.makeText(this, "User already exists or error.", Toast.LENGTH_SHORT).show();
            }
        });

    }
}
