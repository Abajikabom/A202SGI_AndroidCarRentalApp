package com.example.carrentalapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.card.MaterialCardView;

public class HomeActivity extends AppCompatActivity{

    private int userID = -1;
    private String userEmail = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        if (getIntent() != null) {
            userID = getIntent().getIntExtra("USER_ID", -1);
            userEmail = getIntent().getStringExtra("USER_EMAIL");
        }

        TextView homeWelcome = findViewById(R.id.homeWelcome);
        if (userEmail != null && !userEmail.isEmpty()) {
            homeWelcome.setText("Welcome, " + userEmail);
        } else {
            homeWelcome.setText("Welcome");
        }

        MaterialCardView cardBrowse = findViewById(R.id.cardBrowse);
        MaterialCardView cardBookings = findViewById(R.id.cardBookings);
        MaterialCardView cardRentOut = findViewById(R.id.cardRentOut);

        cardBrowse.setOnClickListener(v -> {
            Intent i = new Intent(HomeActivity.this, BrowseCarActivity.class);
            i.putExtra("USER_ID", userID);
            startActivity(i);
        });

        cardBookings.setOnClickListener(v-> {
            Intent i = new Intent(HomeActivity.this, MyBookingActivity.class);
            i.putExtra("USER_ID", userID);
            startActivity(i);
        });

        cardRentOut.setOnClickListener(v -> {
            Intent i = new Intent(HomeActivity.this, RentYourCarActivity.class);
            i.putExtra("USER_ID", userID);
            startActivity(i);
        });
    }
}
