package com.example.carrentalapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

public class DataBaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "carrental.db";
    private static final int DB_VERSION = 1;
    private static final String TABLE_USERS = "Users"; // Ensure table name matches your DB

    private final Context context;
    private SQLiteDatabase db;
    private final String dbPath;

    public DataBaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        this.context = context;
        this.dbPath = context.getDatabasePath(DB_NAME).getPath();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }


    private void copyDatabaseFromAssets() {
        try {
            File dbFile = new File(dbPath);

            if (dbFile.exists()) {
                return;
            }

            dbFile.getParentFile().mkdirs();

            InputStream input = context.getAssets().open("databases/" + DB_NAME);
            OutputStream output = new FileOutputStream(dbPath);

            byte[] buffer = new byte[1024];
            int length;
            while ((length = input.read(buffer)) > 0) {
                output.write(buffer, 0, length);
            }

            output.flush();
            output.close();
            input.close();

            System.out.println("✅ Database copied successfully from assets!");
        } catch (IOException e) {
            e.printStackTrace();
            throw new Error("❌ Error copying prebuilt database");
        }
    }

    public void openDatabase() throws SQLException {
        File dbFile = new File(dbPath);
        if (!dbFile.exists()) {
            copyDatabaseFromAssets();
        }
        db = SQLiteDatabase.openDatabase(dbPath, null, SQLiteDatabase.OPEN_READWRITE);
    }

    @Override
    public synchronized void close() {
        if (db != null)
            db.close();
        super.close();
    }

    public boolean insertUser(String name, String email, String password) {
        try {
            openDatabase();

            // Check if email already exists
            Cursor cursor = db.rawQuery("SELECT * FROM Users WHERE email = ?", new String[]{email});
            if (cursor.getCount() > 0) {
                cursor.close();
                db.close();
                System.out.println("⚠️ Email already registered!");
                return false;
            }
            cursor.close();

            // Insert new record
            ContentValues values = new ContentValues();
            values.put("name", name);
            values.put("email", email);
            values.put("password", password);

            long result = db.insert("Users", null, values);
            db.close();

            if (result == -1) {
                System.out.println("❌ Failed to insert new user.");
                return false;
            } else {
                System.out.println("✅ User registered successfully!");
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }



    public boolean checkUser(String email, String password) {
        boolean exists = false;
        try {
            openDatabase();
            Cursor cursor = db.rawQuery(
                    "SELECT * FROM " + TABLE_USERS + " WHERE email=? AND password=?",
                    new String[]{email, password}
            );
            exists = cursor.getCount() > 0;
            cursor.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return exists;
    }

    public int getUserIdByEmail(String email) {
        int userID = -1;
        try {
            openDatabase();
            Cursor cursor = db.rawQuery(
                    "SELECT id FROM " + TABLE_USERS + " WHERE email=? LIMIT 1",
                    new String[]{email}
            );
            if (cursor != null && cursor.moveToFirst()) {
                userID = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                cursor.close();
            }
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return userID;
    }

    public boolean insertBooking(int userId, int carId, String startDate, String endDate, double totalPrice) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("car_id", carId);
        values.put("start_date", startDate);
        values.put("end_date", endDate);
        values.put("total_price", totalPrice);

        long result = db.insert("Booking", null, values);
        if (result == -1) return false;

        ContentValues carValues = new ContentValues();
        carValues.put("available", 0);
        db.update("Car", carValues, "id=?", new String[]{String.valueOf(carId)});
        db.close();
        return true;
    }

    public ArrayList<Booking> getBookingsByUser(int userId) {
        ArrayList<Booking> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT b.*, car_name AS car_name " +
                "FROM Booking b JOIN Car c ON b.car_id = c.id " +
                "WHERE b.user_id = ?";

        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(userId)});

        if (cursor.moveToFirst()) {
            do {
                Booking booking = new Booking();
                booking.setId(cursor.getInt(cursor.getColumnIndexOrThrow("id")));
                booking.setCarId(cursor.getInt(cursor.getColumnIndexOrThrow("car_id")));
                booking.setStartDate(cursor.getString(cursor.getColumnIndexOrThrow("start_date")));
                booking.setEndDate(cursor.getString(cursor.getColumnIndexOrThrow("end_date")));
                booking.setTotalPrice(cursor.getDouble(cursor.getColumnIndexOrThrow("total_price")));
                booking.setCarName(cursor.getString(cursor.getColumnIndexOrThrow("car_name")));
                list.add(booking);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return list;
    }

    public boolean insertCar(int ownerId, String carName, String brand, String type,
                             double pricePerDay, int available, String imagePath, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("owner_id", ownerId);
        values.put("car_name", carName);
        values.put("brand", brand);
        values.put("type", type);
        values.put("price_per_day", pricePerDay);
        values.put("available", available);
        values.put("image", imagePath);
        values.put("description", description);

        long result = db.insert("Car", null, values);
        db.close();
        return result != -1;
    }




}
