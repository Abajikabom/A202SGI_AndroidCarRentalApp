package com.example.carrentalapp;

public class CarDB {
    private int id;
    private int ownerId;
    private String carName;
    private String brand;
    private String type;
    private double pricePerDay;
    private int available;
    private String image;
    private String description;

    public CarDB (int id, int ownerId, String carName, String brand, String type, double pricePerDay, int available, String image, String description) {
        this.id = id;
        this.ownerId = ownerId;
        this.carName = carName;
        this.brand = brand;
        this.type = type;
        this.pricePerDay = pricePerDay;
        this.available = available;
        this.image = image;
        this.description = description;
    }
    public int getId() {return id; }
    public int getOwnerId() {return ownerId; }
    public String getCarName() {return carName; }
    public String getBrand() {return brand; }
    public String getType() {return type; }
    public double getPricePerDay() {return pricePerDay; }
    public int getAvailable() {return available; }
    public String getImage() {return image; }
    public String getDescription() {return description; }
}
