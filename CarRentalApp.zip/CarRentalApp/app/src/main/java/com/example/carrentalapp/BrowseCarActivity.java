package com.example.carrentalapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.carrentalapp.CarAdapter;
import com.example.carrentalapp.CarDB;
import java.util.ArrayList;
import java.util.List;
public class BrowseCarActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private CarAdapter adapter;
    private List<CarDB> carList = new ArrayList<>();
    private DataBaseHelper dbHelper;
    private int userID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browse_cars);

        recyclerView = findViewById(R.id.recyclerCars);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        dbHelper = new DataBaseHelper(this);
        userID = getIntent().getIntExtra("USER_ID", -1);

        loadCarsFromDB();
    }

    private void loadCarsFromDB(){
        try {
            dbHelper.openDatabase();
            Cursor cursor = dbHelper.getReadableDatabase().rawQuery("SELECT * FROM Car", null);

            carList.clear();
            if(cursor.moveToFirst()) {
                do {
                    int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                    int ownerId = cursor.getInt(cursor.getColumnIndexOrThrow("owner_id"));
                    String carName = cursor.getString(cursor.getColumnIndexOrThrow("car_name"));
                    String brand = cursor.getString(cursor.getColumnIndexOrThrow("brand"));
                    String type = cursor.getString(cursor.getColumnIndexOrThrow("type"));
                    double price = cursor.getDouble(cursor.getColumnIndexOrThrow("price_per_day"));
                    int available = cursor.getInt(cursor.getColumnIndexOrThrow("available"));
                    String image = cursor.getString(cursor.getColumnIndexOrThrow("image"));
                    String description = cursor.getString(cursor.getColumnIndexOrThrow("description"));

                    carList.add(new CarDB(id, ownerId, carName, brand, type, price, available, image, description));

                } while (cursor.moveToNext());
            }

            cursor.close();
            dbHelper.close();

            adapter = new CarAdapter(this, carList, car -> {
                Intent intent = new Intent(BrowseCarActivity.this, CarDetailsActivity.class);
                intent.putExtra("CAR_ID", car.getId());
                intent.putExtra("CAR_NAME", car.getCarName());
                intent.putExtra("CAR_BRAND", car.getBrand());
                intent.putExtra("CAR_TYPE", car.getType());
                intent.putExtra("CAR_DESC", car.getDescription());
                intent.putExtra("CAR_PRICE", car.getPricePerDay());
                intent.putExtra("CAR_AVAILABLE", car.getAvailable());
                intent.putExtra("CAR_IMAGE", car.getImage());
                startActivity(intent);
            });
            recyclerView.setAdapter(adapter);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error loading cars", Toast.LENGTH_SHORT).show();
        }
    }
}
